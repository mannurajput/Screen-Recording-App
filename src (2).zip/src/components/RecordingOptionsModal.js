import React from 'react';
import { FaTimes } from 'react-icons/fa';

const RecordingOptionsModal = ({ showOptions, setShowOptions, withAudio, setWithAudio, withWebcam, setWithWebcam, handleRecordingOptions }) => {
  return (
    <>
      {showOptions && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-white p-6 rounded-lg shadow-lg relative" style={{ width: '400px' }}>
            <button
              onClick={() => setShowOptions(false)}
              className="absolute top-0 right-0 mt-2 mr-2 text-gray-500 hover:text-gray-700"
            >
              <FaTimes size={24} />
            </button>
            <h2 className="text-xl mb-4">Select Recording Options</h2>
            <div className="flex flex-col space-y-2">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={withAudio}
                  onChange={() => setWithAudio(!withAudio)}
                />
                <span>Record Screen with Audio</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={withWebcam}
                  onChange={() => setWithWebcam(!withWebcam)}
                />
                <span>Record Screen with Webcam</span>
              </label>
            </div>
            <button
              onClick={handleRecordingOptions}
              className="bg-blue-500 text-white py-2 px-4 mt-4 rounded"
            >
              Start Recording
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default RecordingOptionsModal;
