import React from 'react';
import { FaTimes } from 'react-icons/fa';

const RecordedVideoModal = ({ showModal, resetRecording, recordedVideoUrl }) => {
  return (
    <>
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-white p-6 rounded-lg shadow-lg relative" style={{ width: '967px', height: '487px' }}>
            <button
              onClick={resetRecording}
              className="absolute top-0 right-0 mt-2 mr-2 text-gray-500 hover:text-gray-700"
            >
              <FaTimes size={24} />
            </button>
            <video src={recordedVideoUrl} controls autoPlay className="w-full h-full rounded-lg" />
          </div>
        </div>
      )}
    </>
  );
};

export default RecordedVideoModal;
