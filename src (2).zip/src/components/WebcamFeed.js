import React from 'react';
import Webcam from 'react-webcam';

const WebcamFeed = ({ webcamVideoRef }) => {
  return (
    <Webcam
      audio={false}
      ref={ webcamVideoRef }
      className="fixed bottom-10 object-cover right-10 w-[234px] h-[234px]  rounded-full border-4 border-[#EAEAEA] z-50"
    />
  );
};

export default WebcamFeed;
