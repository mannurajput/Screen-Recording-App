import React from 'react';
import { FaTrash, FaDownload } from 'react-icons/fa';

const VideoPage = () => {
  const recordings = JSON.parse(localStorage.getItem('recordings')) || [];

  const deleteRecording = (index) => {
    const updatedRecordings = recordings.filter((_, i) => i !== index);
    localStorage.setItem('recordings', JSON.stringify(updatedRecordings));
    window.location.reload(); // To re-render the component
  };

  const downloadRecording = (url, index) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = `recording_${index}.webm`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl mb-4 font-bold text-center text-gray-800">Recorded Videos</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {recordings.map((recording, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-lg relative">
            <video src={recording.url} controls className="w-full rounded-lg mb-4" />
            <div className="flex justify-between items-center mt-2">
              <button
                onClick={() => downloadRecording(recording.url, index)}
                className="text-blue-500 hover:text-blue-700 p-2"
              >
                <FaDownload size={20} />
              </button>
              <button
                onClick={() => deleteRecording(index)}
                className="text-red-500 hover:text-red-700 p-2"
              >
                <FaTrash size={20} />
              </button>
            </div>
            <p className="text-sm text-gray-600 mt-4 text-right">{new Date(recording.date).toLocaleString()}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VideoPage;
