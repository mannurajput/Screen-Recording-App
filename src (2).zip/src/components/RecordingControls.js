import React from 'react';
import { FaRecordVinyl, FaStop } from 'react-icons/fa';

const RecordingControls = ({ isRecording, startRecording, stopRecording, timer }) => {
  return (
    <div className="relative z-10 flex flex-col items-center">
      <div className="mt-4 flex items-center space-x-4">
        {!isRecording ? (
          <button onClick={startRecording} className="bg-red-500 text-white py-2 px-4 rounded flex items-center">
            <FaRecordVinyl className="mr-2" />
            Start Recording
          </button>
        ) : (
          <button
            id="stopButton"
            onClick={stopRecording}
            className="bg-yellow-500 text-white py-2 px-4 rounded flex items-center fixed top-4 left-4 z-50"
          >
            <FaStop className="mr-2" />
            Stop Recording
          </button>
        )}
      </div>
      {isRecording && (
        <div id="timerDisplay" className="mt-2 text-xl fixed top-4 right-4 z-50">
          Recording Time: {timer}s
        </div>
      )}
    </div>
  );
};

export default RecordingControls;
