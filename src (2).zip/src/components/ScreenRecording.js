import React, { useState, useRef } from 'react';
import RecordingControls from './RecordingControls';
import RecordingOptionsModal from './RecordingOptionsModal';
import WebcamFeed from './WebcamFeed';
import RecordedVideoModal from './RecordedVideoModal';

const ScreenRecording = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [timer, setTimer] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [withAudio, setWithAudio] = useState(false);
  const [withWebcam, setWithWebcam] = useState(false);

  const mediaChunks = useRef([]);
  const intervalRef = useRef(null);
  const streamRef = useRef(null);
  const webcamRef = useRef(null);
  const webcamVideoRef = useRef(null);

  const startRecording = () => {
    setShowOptions(true);
  };

  const handleRecordingOptions = async () => {
    setShowOptions(false);
    try {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      streamRef.current = displayStream;

      if (withAudio) {
        const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioStream.getAudioTracks().forEach(track => displayStream.addTrack(track));
      }

      if (withWebcam) {
        const webcamStream = await navigator.mediaDevices.getUserMedia({ video: true });
        webcamRef.current = webcamStream;

        if (webcamVideoRef.current) {
          webcamVideoRef.current.srcObject = webcamStream;
          webcamVideoRef.current.onloadedmetadata = () => {
            webcamVideoRef.current.play();
          };
        }

        const combinedStream = new MediaStream([
          ...displayStream.getTracks(),
          ...webcamStream.getTracks(),
        ]);
        streamRef.current = combinedStream;
      }

      const recorder = new MediaRecorder(streamRef.current);
      recorder.ondataavailable = (event) => {
        mediaChunks.current.push(event.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(mediaChunks.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        setRecordedVideoUrl(url);
        setShowModal(true);
        mediaChunks.current = [];
        saveRecording(url);
      };

      setMediaRecorder(recorder);
      recorder.start();

      setIsRecording(true);
      setTimer(0);
      intervalRef.current = setInterval(() => {
        setTimer(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error starting screen recording:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    if (webcamRef.current) {
      webcamRef.current.getTracks().forEach(track => track.stop());
    }
    setIsRecording(false);
    clearInterval(intervalRef.current);
  };

  const resetRecording = () => {
    setRecordedVideoUrl(null);
    setShowModal(false);
  };

  const saveRecording = (url) => {
    const recordings = JSON.parse(localStorage.getItem('recordings')) || [];
    recordings.push({ url, date: new Date() });
    localStorage.setItem('recordings', JSON.stringify(recordings));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 relative">
      {isRecording && (
        <div className="fixed inset-0 border-4 border-green-500 transition-colors duration-300 pointer-events-none">
          {/* Screen Recording Border */}
        </div>
      )}
      <RecordingControls
        isRecording={isRecording}
        startRecording={startRecording}
        stopRecording={stopRecording}
        timer={timer}
      />
      <RecordingOptionsModal
        showOptions={showOptions}
        setShowOptions={setShowOptions}
        withAudio={withAudio}
        setWithAudio={setWithAudio}
        withWebcam={withWebcam}
        setWithWebcam={setWithWebcam}
        handleRecordingOptions={handleRecordingOptions}
      />
      {isRecording && withWebcam && (
        <WebcamFeed webcamVideoRef={webcamVideoRef} />
      )}
      <RecordedVideoModal
        showModal={showModal}
        resetRecording={resetRecording}
        recordedVideoUrl={recordedVideoUrl}
      />
    </div>
  );
};

export default ScreenRecording;
