import React from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import ScreenRecording from './components/ScreenRecording';
import VideoPage from './components/VideoPage';

const App = () => {
  return (
    <Router>
      <div className="p-5 ">
       <nav className="mb-4 text-center bg-[#FAFAFA]">
          <Link to="/" className="mr-4 text-blue-500">Home</Link>
          <Link to="/videos" className="text-blue-500">Recorded Videos</Link>
        </nav>
        <Routes>
      
          <Route path="/" element={<ScreenRecording />} />
          <Route path="/videos" element={<VideoPage />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
